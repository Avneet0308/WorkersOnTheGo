﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Web.Security;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
using System.IO;
using System.Collections.Specialized;

namespace HackWithPSIT
{
    public partial class Home : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["WorkersOnTheGo"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("SELECT Name from Customer_Details where id=1", conn);
            SqlCommand cmd1 = new SqlCommand("SELECT Address from Customer_Details where id=1", conn);
            SqlCommand cmd2 = new SqlCommand("SELECT PhoneNo from Customer_Details where id=1", conn);
            conn.Open();
            NameBox.Text = cmd.ExecuteScalar().ToString();
            AddressBox.Text = cmd1.ExecuteScalar().ToString();
            MobileNoBox.Text = cmd2.ExecuteScalar().ToString();
            conn.Close();
        }

        protected void SubmitButton_Click(object sender, EventArgs e)
        {
            
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            WTypeList.SelectedValue = "Avneet";
        }
    }
}